const a = new Map();

a.set("abc", a.get("a"));
console.log(a.get("abc"));
